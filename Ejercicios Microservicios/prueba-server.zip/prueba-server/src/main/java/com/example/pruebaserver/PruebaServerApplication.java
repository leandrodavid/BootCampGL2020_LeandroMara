package com.example.pruebaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaServerApplication.class, args);
	}

}
